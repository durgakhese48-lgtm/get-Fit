
var express = require("express");
var data =require("./data")
var dbconfig = require("./dbconfig");
var user= require("./user");


let app= express();

app.get("/",(req,res)=>{
res.send(data)
})
app.listen(5500,()=>{
    console.log("server is running")
})
