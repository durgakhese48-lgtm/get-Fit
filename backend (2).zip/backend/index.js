var http=require("http")

http.createServer(function(req,res){
res.write("hello ...good mornings ")   
res.end() 
}

).listen(5000,()=>{
    console.log("server is running")
});