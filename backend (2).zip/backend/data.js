const data = [
{name:"John",
city:"Mumbai",
id:567
},

{name:"Wick",
city:"Pune",
id:568
},

{name:"Sanskruti",
city:"Dhayari",
id:569
},

{name:"Durga",
city:"Saswad",
id:570
},

{name:"Mayuresh",
city:"Katraj",
id:571
},



]

module.exports=data